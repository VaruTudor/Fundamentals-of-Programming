class BadIDError(Exception):
    pass
class BadNameError(Exception):
    pass
class BadPhoneNo(Exception):
    pass
class NonExistentID(Exception):
    pass
class BadDateError(Exception):
    pass
class BadTimeError(Exception):
    pass
class OverlapError(Exception):
    pass